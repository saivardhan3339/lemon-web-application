# LittleLemon
APIs paths:
restaurant/menu
&
restaurant/booking/tables

(Note: I created the tests folder at the app level)
